package Employeee;

//import com.toedter.calendar.JDateChooser;
import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import java.util.Calendar;

class Add_Employee implements ActionListener{

    JFrame f;
    JLabel id,id1,id2,id3,id4,id5,id6,id7,id8,id9,id10,id11,id12,id15,id16,id17,lab,lab1;
    JTextField name,fname,age,address,phone,email,dob,post,education,aadhar,emp_id;
    JButton b,b1,b2,b3;
//    JComboBox post;
//    JDateChooser dob;

    Add_Employee(int i){}
    
    Add_Employee(){
        f = new JFrame("Add Employee");
        f.setBackground(Color.white);
        f.setLayout(null);

        id15=new JLabel();
        id15.setBounds(0,0,900,700);
        id15.setLayout(null);
        ImageIcon img = new ImageIcon(ClassLoader.getSystemResource("Employeee/icons/add_employee.jpg"));
        id15.setIcon(img);

        id8 = new JLabel("New Employee Details");
        id8.setBounds(320,30,500,50);
        id8.setFont(new Font("serif",Font.ITALIC,25));
        id8.setForeground(Color.black);
        id15.add(id8);
        f.add(id15);

 
        id1 = new JLabel("Name");
        id1.setBounds(50,150,100,30);
        id1.setFont(new Font("serif",Font.BOLD,20));
        id15.add(id1);

        name=new JTextField();
        name.setBounds(200,150,150,30);
        id15.add(name);

        id2 = new JLabel("Sir Name");
        id2.setBounds(400,150,200,30);
        id2.setFont(new Font("serif",Font.BOLD,20));
        id15.add(id2);

        fname=new JTextField();
        fname.setBounds(600,150,150,30);
        id15.add(fname);

        id3= new JLabel("Age");
        id3.setBounds(50,200,100,30);
        id3.setFont(new Font("serif",Font.BOLD,20));
        id15.add(id3);

        age=new JTextField();
        age.setBounds(200,200,150,30);
        id15.add(age);

        id4= new JLabel("Date Of Birth");  
        id4.setBounds(400,200,200,30);
        id4.setFont(new Font("serif",Font.BOLD,20));
        id15.add(id4);
        
//        dob =new JDateChooser();
//        dob.setBounds(600,200,150,30);
//        id15.add(dob);

        dob=new JTextField();
        dob.setBounds(600,200,150,30);
        id15.add(dob);

         

        id5= new JLabel("Address");
        id5.setBounds(50,250,100,30);
        id5.setFont(new Font("serif",Font.BOLD,20));
        id15.add(id5);

        address=new JTextField();
        address.setBounds(200,250,150,30);
        id15.add(address);

        id6= new JLabel("Phone");
        id6.setBounds(400,250,100,30);
        id6.setFont(new Font("serif",Font.BOLD,20));
        id15.add(id6);

        phone=new JTextField();
        phone.setBounds(600,250,150,30);
        id15.add(phone);

        id7= new JLabel("Email Id");
        id7.setBounds(50,300,100,30);
        id7.setFont(new Font("serif",Font.BOLD,20));
        id15.add(id7);

        email=new JTextField();
        email.setBounds(200,300,150,30);
        id15.add(email);

        id9= new JLabel("Education");
        id9.setBounds(400,300,100,30);
        id9.setFont(new Font("serif",Font.BOLD,20));    
        id15.add(id9);

        education=new JTextField();
        education.setBounds(600,300,150,30);
        id15.add(education);

        id10= new JLabel("Job Post");
        id10.setBounds(50,350,100,30);
        id10.setFont(new Font("serif",Font.BOLD,20));
        id15.add(id10);
        
//        post =jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
//        post.addActionListener(new java.awt.event.ActionListener())
//        post.setBounds(400, 350, 150, 30);
//        post.add(post);

        post=new JTextField();
        post.setBounds(200,350,150,30);
        id15.add(post);

        id11= new JLabel("Aadhar No");
        id11.setBounds(400,350,100,30);
        id11.setFont(new Font("serif",Font.BOLD,20));
        id15.add(id11);

        aadhar=new JTextField();
        aadhar.setBounds(600,350,150,30);
        id15.add(aadhar);

        id12= new JLabel("Employee Id");
        id12.setBounds(50,400,150,30);
        id12.setFont(new Font("serif",Font.BOLD,20));
        id15.add(id12);

        emp_id=new JTextField();   
        emp_id.setBounds(200,400,150,30);
        id15.add(emp_id);

        

        lab=new JLabel();
        lab.setBounds(200,450,250,200);
	id15.add(lab);

//        lab1=new JLabel("");
//        lab1.setBounds(600,450,250,200);
//        id15.add(lab1);

        b = new JButton("Submit");
        b.setBackground(Color.BLACK);
        b.setForeground(Color.WHITE);
        b.setBounds(250,550,150,40);
        
        id15.add(b);

        b1=new JButton("Cancel");   
        b1.setBackground(Color.BLACK);
        b1.setForeground(Color.WHITE);
        b1.setBounds(450,550,150,40);
        
        id15.add(b1);
        
        b.addActionListener(this);
        b1.addActionListener(this);
        
        f.setVisible(true);
        f.setSize(900,700);
        f.setLocation(400,150);
    }

    @Override
    public void actionPerformed(ActionEvent ae){
        
        String a = name.getText();
        String bb = fname.getText();
        String c = age.getText();
        String d = dob.getText();
        String e = address.getText();
        String ff = phone.getText();
        String g = email.getText();
        String h = education.getText();
        String i = post.getText();
        String j = aadhar.getText();
        String k = emp_id.getText();
        if(ae.getSource() == b){
            try{
                conn cc = new conn();
                String q = "insert into employee values('"+a+"','"+bb+"','"+c+"','"+d+"','"+e+"','"+ff+"','"+g+"','"+h+"','"+i+"','"+j+"','"+k+"')";
                cc.s.executeUpdate(q);
                JOptionPane.showMessageDialog(null,"Details Successfully Inserted");
                f.setVisible(false);
                new details();
            }catch(Exception ee){
                System.out.println("The error is:"+ee);
            }
        }else if(ae.getSource() == b1){
            f.setVisible(false);
            new details();
        }
    }
    public static void main(String[ ] arg){
        new Add_Employee();
    }
}
